import UIKit

func hesapla (islemler:(_ a:Double, _ b:Double) -> Double , num1:Double, num2: Double) -> Double
{
    return islemler(num1 , num2)
    
}
func toplama (_ x:Double , _ y:Double) -> Double
{
    return x + y
}
func cikarma (_ x:Double , _ y:Double) -> Double
{
    return x - y
    
}
func carpma (_ x:Double , _ y:Double) -> Double
{
    return x * y
    
}
func bolme (_ x:Double , _ y:Double) -> Double
{
    return x / y

}

hesapla(islemler: toplama(_:_:), num1: 10, num2: 5)
hesapla(islemler: cikarma(_:_:), num1: 10, num2: 5)
hesapla(islemler: carpma(_:_:), num1: 10, num2: 5)
hesapla(islemler: bolme(_:_:), num1: 10, num2: 5)

